#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

# Updates..

updates() {

	cd /home/$USERNAME/Desktop/ && wget --no-check-certificate https://github.com/alectramell/rabbithole/raw/master/alectramell.pdf

}

clear

updates

clear


