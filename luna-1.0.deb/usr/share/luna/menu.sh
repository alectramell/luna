#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

# Updates..

updates() {

	rm /home/$USERNAME/.luna.html
	cd /home/$USERNAME/ && wget --no-check-certificate https://github.com/alectramell/luna/raw/master/index.html
	mv /home/$USERNAME/index.html /home/$USERNAME/.luna.html

}

clear

CONNECT=$(ping -q -w 1 -c 1 `ip r | grep default | cut -d ' ' -f 3` > /dev/null && clear && echo ok || echo error)

if [ $CONNECT = "ok" ]
then
	updates
else
	clear
	zenity --info --title="Luna v1.0" --text="You are not online, please connect to a network.." --no-cancel
	clear
	exit

clear

sensible-browser --new-window="file:///home/$USERNAME/.luna.html"

clear


