#!/bin/bash

clear

USERNAME=$(whoami)
WHEREAMI=$(pwd)

clear

# Updates..

updates() {

	cd /home/$USERNAME/ && wget --no-check-certificate https://github.com/alectramell/luna/raw/master/index.html
	mv /home/$USERNAME/index.html /home/$USERNAME/luna.html

}

clear

updates

clear

sensible-browser --new-window="file:///home/$USERNAME/luna.html"

clear


